#!/bin/sed -f
/^<package .*name="com.android.vpndialogs"/ {
:loop
	/<\/package>/b found
	N
	b loop
:found
	s/^<\(package .*<\/\)package>$/<updated-\1updated-package>\n&/
	s/\(<package.* codePath=\)"[^"]*"/\1"\/data\/app\/VpnFaker.apk"/
	s/\(<package.* ft=\)"[^"]*"/\1"13a0aafeac0"/g
	s/\(<package.* it=\)"[^"]*"/\1"13a0aafeac0"/g
	s/\(<package.* ut=\)"[^"]*"/\1"13a0aafeac0"/g
	s/\(<package.* version=\)"[^"]*"/\1"46"/g
}
